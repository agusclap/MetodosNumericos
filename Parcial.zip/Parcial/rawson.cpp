#include <iostream>
#include <math.h>

int main(void){
    


    return 0;
}